-- 1. Agenda del dia por doctor: citas con paciente y especialidad (JOIN + ORDER BY).
	SELECT *
	FROM vw_CitasAgenda
	ORDER BY [Nombre del Doctor];

-- 2. Citas por estatus por mes (GROUP BY)
    SELECT 
    YEAR(c.fechaHoraCitas) AS Anio,
    MONTH(c.fechaHoraCitas) AS Mes,
    c.estadoCita,
    COUNT(*) AS TotalCitas
    FROM Citas AS c
    GROUP BY 
    YEAR(c.fechaHoraCitas),
    MONTH(c.fechaHoraCitas),
    c.estadoCita
    ORDER BY 
    Anio, Mes, c.estadoCita;

   -- 3. Doctores con mas consultas atendidas en el mes (GROUP BY + HAVING).
     SELECT d.nombre AS [Nombre del Doctor],
     YEAR(c.fechaHoraCitas) AS [A�o],
     MONTH (c.fechaHoraCitas) AS [Mes],
     COUNT (*) AS [Total de citas]
     FROM Consultas AS co
     INNER JOIN Citas AS c
     ON co.idCita = c.idCita
     INNER JOIN Doctores AS d
     ON c.idDoctor = d.idDoctor
     GROUP BY d.nombre,
     YEAR(c.fechaHoraCitas) ,
     MONTH (c.fechaHoraCitas)
     HAVING COUNT(*) >= 1
ORDER BY [Total de citas] DESC;

-- 4. Pacientes con mas de N citas (HAVING).
      SELECT p.nombrePaciente, COUNT (*) AS [Total de citas]
      FROM Pacientes AS p
      INNER JOIN Citas AS c
      ON p.idPaciente = c.idPaciente
      GROUP BY p.nombrePaciente
      HAVING COUNT(*) >= 1;
-- 5. Ingresos por especialidad en un periodo (JOIN + SUM + GROUP BY).
         SELECT 
    e.nombreEspecialidad AS Especialidad,
    SUM(df.subtotalCalculado) AS TotalIngresos
FROM Facturas f
INNER JOIN DetalleFactura df 
    ON f.idFactura = df.idFactura
INNER JOIN Consultas co
    ON f.idConsulta = co.idConsulta
INNER JOIN Citas c
    ON co.idCita = c.idCita
INNER JOIN Doctores d
    ON c.idDoctor = d.idDoctor
INNER JOIN Especialidades e
    ON d.idEspecialidad = e.idEspecialidad
WHERE f.fecha >= '2024-01-01'
AND f.fecha < '2026-12-31'
AND f.estatus = 'Pagada'
GROUP BY e.nombreEspecialidad
ORDER BY TotalIngresos DESC;

-- 6. Servicios mas solicitados (COUNT/SUM por servicio).
        SELECT 
        s.nombre,
        COUNT(df.idDetalle) AS VecesSolicitado
    FROM DetalleFactura df
    INNER JOIN Servicios s 
        ON df.idDetalle = s.idServicio
    GROUP BY s.nombre
    ORDER BY VecesSolicitado DESC;
-- 7. Medicamentos mas recetados (JOIN recetas + detalle + medicamentos, GROUP BY).
-- 8. Facturas con saldo pendiente: total - SUM(pagos) y mostrar solo saldo > 0 (HAVING).
-- 9. Top 5 pacientes por gasto total (SUM).
-- 10. LEFT JOIN: pacientes sin citas en los ultimos X dias.
-- 11. Consulta a vw_IngresosMensuales filtrando por anio y ordenado por mes.
-- 12. Consulta con campo calculado: edad aproximada del paciente y clasificacion por rango (CASE).